/**
 * The {@link org.jfree.chart.plot.CompassPlot} class and related code.
*/
package org.jfree.chart.plot.compass;
