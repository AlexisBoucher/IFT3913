Alexis Boucher 20217120
Marguerite Mireille Camara 20143122

Lien GitHub:
https://github.com/AlexisBoucher/IFT3913
