Places vos tests ici. Utilisation de JUnit5 requise.



Tests: 
testBoiteNoire
    MainWindowTestBoiteNoire.java
    CurrencyTestBoiteNoire
testBoiteBlanche
    MainWindowTestBoiteBlanche.java
    CurrencyTestBoiteBlanche.java